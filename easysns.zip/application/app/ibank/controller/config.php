<?php

$app_config['id'] = 'ibank';
$app_config['name'] = '社区银行';
$app_config['desc'] = '可以在这里存取款,还可以通过网上银行兑换金币';
$app_config['develop'] = 'easysns.com';

$app_config['icon'] = '/static/icon/coins.png';
$app_config['left'] = 1;

?>