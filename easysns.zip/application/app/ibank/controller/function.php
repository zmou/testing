<?php

$tab_array = array
(
	'index' => '大厅',
	'convert' => '兑换',
	'transfer' => '转账',
	'recharge' => '充值',
	//'petbank' => '宠物银行',

//	'tab2' => 'TAB2',
	
	
);




?>