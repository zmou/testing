<?php

$app_config['id'] = 'ishopcart';
$app_config['name'] = '购物车';
$app_config['desc'] = '购物车';
$app_config['develop'] = 'easysns.com';

$app_config['icon'] = '/static/icon/cart.gif';
$app_config['left'] = 1;

?>