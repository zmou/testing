<?php

$app_config['id'] = 'iforum';
$app_config['name'] = '讨论区';
$app_config['desc'] = '关于社区的一切都可以在这里讨论哦';
$app_config['develop'] = 'easysns.com';

$app_config['icon'] = '/static/icon/iforum.gif';
$app_config['left'] = 1;

?>