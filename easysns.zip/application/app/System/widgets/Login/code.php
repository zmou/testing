<?php
function get_system_register_data($para = NULL)
{
	 $data['text'] = 'hello Kitty!';

	 return $data;
}
?>