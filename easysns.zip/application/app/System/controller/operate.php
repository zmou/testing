<?php
$install['sql'][] = "";
$uninstall['table'][] = '';
$widgets['Activeuser'] = '活跃用户';
$widgets['Usersearch'] = '用户搜索';
$widgets['Vote'] = '投票';
$widgets['NewUser'] = '最新用户';
$widgets['Login'] = '登陆面板';
$widgets['Textarea'] = '文本框';
$widgets['Rss'] = 'RSS聚合';
$widgets['Register'] = '快速注册';
$widgets['ProList'] = '文章列表';
$widgets['Image'] = '变换图片';
$widgets['Display'] = '显示文章';
$widgets['Image'] = '变换图片';
$widgets['Service'] = '在线咨询';
$widgets['News'] = '新鲜事';
?>