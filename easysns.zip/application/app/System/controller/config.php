<?php

$app_config['id'] = 'system';
$app_config['name'] = '系统';
$app_config['desc'] = '系统插件';
$app_config['develop'] = 'easysns.com';

$app_config['icon'] = '';
$app_config['left'] = 0;

?>