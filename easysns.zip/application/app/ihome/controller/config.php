<?php

$app_config['id'] = 'ihome';
$app_config['name'] = '个人中心';
$app_config['desc'] = '个人数据中心,各种数据都能看到哦~';
$app_config['develop'] = 'easysns.com';

$app_config['icon'] = '/static/icon/user.png';
$app_config['left'] = 1;

?>