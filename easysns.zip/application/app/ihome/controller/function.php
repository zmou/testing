<?php

$tab_array = array
(
	'index' => '首页',
	//'diary' => '日记',
	//'album' => '相册',
);

?>