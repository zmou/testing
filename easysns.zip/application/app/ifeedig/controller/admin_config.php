<?php 
$config['update_time'] = '600';
$config['titles'] = array (
  1 => '全部咨询',
  2 => '动漫',
  3 => '测试',
);
$config['days'] = array (
  1 => '24小时',
  7 => '7天',
  365 => '365天',
);
$config['state'] = array (
  1 => '需要验证',
  2 => '直接通过',
);

?>