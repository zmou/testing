<?php
$app_config['id'] = 'ifeedig';
$app_config['name'] = '悦读';
$app_config['desc'] = '社会化阅读工具';
$app_config['develop'] = 'easysns.com';

$app_config['icon'] = '/static/icon/feedig_icon.gif';
$app_config['left'] = 1;
?>