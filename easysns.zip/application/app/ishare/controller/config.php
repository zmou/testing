<?php

$app_config['id'] = 'ishare';
$app_config['name'] = '分享';
$app_config['desc'] = '将你喜欢的东东分享给朋友';
$app_config['develop'] = 'feedig.com';

$app_config['icon'] = '/static/icon/fav.gif';
$app_config['left'] = 1;

?>