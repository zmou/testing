<?php
function life_stream_index()
{ 
	return '郁闷的有100人啊';
}
?>