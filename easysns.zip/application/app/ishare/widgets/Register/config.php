<?php
$config['name'] = 'test';
$config['desc'] = 'testtest';
$config['stats'] = '1';
?>