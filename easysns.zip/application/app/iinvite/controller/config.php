<?php

$app_config['id'] = 'iinvite';
$app_config['name'] = '邀请好友';
$app_config['desc'] = '邀请好友';
$app_config['develop'] = 'easysns.com';

$app_config['icon'] = '/static/icon/user.png';
$app_config['left'] = 0;

?>