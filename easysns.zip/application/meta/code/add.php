<?php

include_once( dirname( __FILE__ ) . '/function.php'   );

$data = array();
$data['ci_top_title'] = '添加';
 


layout( $data , 'default' , 'app' );

?>