<?php
// put common funcitones here 


?>