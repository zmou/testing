<?php
// app config file

$app_config['id'] = 'main';
$app_config['name'] = 'The主应用';
$app_config['desc'] = '{$desc}';
$app_config['develop'] = 'easysns.com';

$app_config['icon'] = '/static/icon/fav.gif';
$app_config['left'] = 0;


?>