<?php

$install['sql'][] = '';
$uninstall['table'][] = '';

?>